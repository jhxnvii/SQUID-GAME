# RedLightGreenLight
Opencv game of Red Light Green Light game from squid game show.
